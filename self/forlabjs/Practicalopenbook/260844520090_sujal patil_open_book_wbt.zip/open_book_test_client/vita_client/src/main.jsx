import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import App from "./App";
import Home from "./Home";
import ContactUs from "./ContactUs";
import ListStudent from "./ListStudent";
import StudentCreate from "./StudentCreate";
import StudentUpdate from "./StudentUpdate";
import StudentDelete from "./StudentDelete";
import NotFound from "./NotFound";

import "./index.css";

createRoot(document.getElementById("root")).render(
    <StrictMode>
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<App />}>
                    <Route index element={<Home />} />
                    <Route path="Home" element={<Home />} />
                    <Route path="ContactUs" element={<ContactUs />} />
                    <Route path="ListStudent" element={<ListStudent />} />
                    <Route path="CreateStudent" element={<StudentCreate />} />
                    <Route path="UpdateStudent/:id" element={<StudentUpdate />} />
                    <Route path="DeleteStudent/:id" element={<StudentDelete />} />
                    <Route path="*" element={<NotFound />} />
                </Route>
            </Routes>
        </BrowserRouter>
    </StrictMode>
);