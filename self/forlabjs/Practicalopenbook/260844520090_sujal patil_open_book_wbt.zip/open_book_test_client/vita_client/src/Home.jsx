import React from "react";

function Home() {
const students = [
{
id: 1,
name: "Shreyas",
image: "/shreyas.jpeg"
},
{
id: 2,
name: "Shiv",
image: "/shiv.png"
},
{
id: 3,
name: "Nidhi",
image: "/nidhi.png"
},
{
id: 4,
name: "Sujal",
image: "/sujal.png"
}
];

return (
    <div>
        <h2>Welcome to Home Page</h2>
        <h3>Student Details</h3>

        {students.map((student) => (
            <div key={student.id}>
                <h3>{student.name}</h3>
                <p>Student ID: {student.id}</p>

                <img
                    src={student.image}
                    alt={student.name}
                    width="150"
                    height="150"
                />
            </div>
        ))}
    </div>
);

}

export default Home;