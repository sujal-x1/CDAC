function Footer() {
    return (
        <footer>
            <hr />
            <p>Copy Right @CDAC.IN</p>
        </footer>
    );
}

export default Footer;