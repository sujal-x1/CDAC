function ContactUs() {
    return (
        <div>
            <h2>Authorised Training Centre...</h2>
            <p>
            5th Floor, Vidyanidhi Education Complex,
                <br />
                Vidyanidhi Road,
                <br />
                Juhu Scheme,
                Andheri (W),
                <br />
                Mumbai 400 049,
                <br />
                India
            </p>
            <p>
                <b>Mobile Number :</b>{" "}
                99999999 / 888888888 / 777777777
            </p>
            <p>
            <b>Email:</b> vita@gmail.com
            </p>
        </div>
    );
}

export default ContactUs;