import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function StudentDelete() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [student, setStudent] = useState(null);
    const [error, setError] = useState("");

    useEffect(() => {
        fetch("http://localhost:8083/student/" + id)
            .then(res => {
                if (!res.ok) throw new Error("Student not found");
                return res.json();
            })
            .then(setStudent)
            .catch(err => setError(err.message));
    }, [id]);

    const handleDelete = async () => {
        try {
            const response = await fetch("http://localhost:8083/student/" + id, {
                method: "DELETE"
            });

            const data = await response.json();
            if (!response.ok) throw new Error(data.message || "Delete failed");

            alert("Student deleted successfully");
            navigate("/ListStudent");
        } catch (err) {
            setError(err.message);
        }
    };

    if (error && !student) return <p>{error}</p>;
    if (!student) return <p>Loading student...</p>;

    return (
        <div>
            <h2>Delete Student</h2>
            <p>Are you sure you want to delete {student.name}?</p>
            <p>ID: {student.id}</p>
            <p>Mobile: {student.mobile}</p>
            <p>Email: {student.email}</p>
            <p>Address: {student.address}</p>

            {error && <p style={{ color: "red" }}>{error}</p>}

            <button onClick={handleDelete}>Confirm Delete</button>
            {" "}
            <button onClick={() => navigate("/ListStudent")}>Cancel</button>
        </div>
    );
}

export default StudentDelete;