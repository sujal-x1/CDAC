import { useState } from "react";
import { Outlet } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";

function App() {
    const [name, setName] = useState("");
    const [loggedIn, setLoggedIn] = useState(false);

    return (
        <>
            <Header
            name={name}
            setName={setName}
            loggedIn={loggedIn}
            setLoggedIn={setLoggedIn}
            />
            <main>
            <Outlet context={{ name, loggedIn }} />
            </main>
            <Footer />
        </>
    );
}

export default App;