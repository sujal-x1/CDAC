import { Link } from "react-router-dom";

function Header({ name, setName, loggedIn, setLoggedIn }) {
    const handleLogin = () => {
        if (name.trim() === "") {
            alert("Please enter your name");
            return;
        }
        setLoggedIn(true);
    };
    const handleLogout = () => {
        setLoggedIn(false);
        setName("");
    };
    return (
        <header>
            <nav>
                <Link to="/">Home</Link>{" | "}
                <Link to="/ContactUs">ContactUs</Link>{" | "}
                <Link to="/ListStudent">ListStudent</Link>
            </nav>

            <div>
                {loggedIn ? (
                    <>
                        <span>Welcome, {name} </span>
                        <button onClick={handleLogout}>Logout</button>
                    </>
                ) : (
                    <>
                        <label>Login: </label>
                        <input
                            type="text"
                            placeholder="Enter name"
                            value={name}
                            onChange={e => setName(e.target.value)}
                        />
                        <button onClick={handleLogin}>Login</button>
                    </>
                )}
            </div>

            <hr />
        </header>
    );
}

export default Header;