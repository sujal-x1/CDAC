import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function StudentUpdate() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [student, setStudent] = useState(null);
    const [error, setError] = useState("");

    useEffect(() => {
        fetch("http://localhost:8083/student/" + id)
            .then(res => {
                if (!res.ok) throw new Error("Student not found");
                return res.json();
            })
            .then(setStudent)
            .catch(err => setError(err.message));
    }, [id]);

    const handleChange = e => {
        setStudent({ ...student, [e.target.name]: e.target.value });
    };

    const handleSubmit = async e => {
        e.preventDefault();

        try {
            const response = await fetch("http://localhost:8083/student/" + id, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(student)
            });

            const data = await response.json();
            if (!response.ok) throw new Error(data.message || "Update failed");

            alert("Student updated successfully");
            navigate("/ListStudent");
        } catch (err) {
            setError(err.message);
        }
    };

    if (error && !student) return <p>{error}</p>;
    if (!student) return <p>Loading student...</p>;

    return (
        <div>
            <h2>Update Student</h2>
            {error && <p style={{ color: "red" }}>{error}</p>}

            <form onSubmit={handleSubmit}>
                <label>ID:</label>
                <input value={student.id} disabled />
                <br /><br />

                <label>Name:</label>
                <input name="name" value={student.name} onChange={handleChange} required />
                <br /><br />

                <label>Mobile:</label>
                <input name="mobile" value={student.mobile} onChange={handleChange} required />
                <br /><br />

                <label>Email:</label>
                <input type="email" name="email" value={student.email} onChange={handleChange} required />
                <br /><br />

                <label>Address:</label>
                <input name="address" value={student.address} onChange={handleChange} required />
                <br /><br />

                <label>Image filename:</label>
                <input name="image" value={student.image} onChange={handleChange} required />
                <br /><br />

                <button type="submit">Update Student</button>
                {" "}
                <button type="button" onClick={() => navigate("/ListStudent")}>
                    Cancel
                </button>
            </form>
        </div>
    );
}

export default StudentUpdate;