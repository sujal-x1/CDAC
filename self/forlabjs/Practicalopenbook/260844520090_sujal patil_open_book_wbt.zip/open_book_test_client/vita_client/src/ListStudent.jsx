import { useEffect, useState } from "react";
import { Link, useOutletContext } from "react-router-dom";

function ListStudent() {
    const { name, loggedIn } = useOutletContext();

    const [students, setStudents] = useState([]);
    const [selectedId, setSelectedId] = useState("");
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (!loggedIn || name !== "VITA") {
            setStudents([]);
            setSelectedId("");
            return;
        }

        const controller = new AbortController();

        async function fetchStudents() {
            setLoading(true);
            setError("");

            try {
                const response = await fetch(
                    "http://localhost:8083/student",
                    { signal: controller.signal }
                );

                if (!response.ok) {
                    throw new Error("Failed to fetch students");
                }

                const data = await response.json();
                setStudents(data);
            } catch (err) {
                if (err.name !== "AbortError") {
                    setError(err.message);
                }
            } finally {
                if (!controller.signal.aborted) {
                    setLoading(false);
                }
            }
        }

        fetchStudents();

        return () => controller.abort();
    }, [loggedIn, name]);

    if (!loggedIn) {
        return <h2>Please login first.</h2>;
    }
    if (name !== "VITA") {
        return <h2>Access Denied. Login with the name VITA.</h2>;
    }
    const student = students.find(
        s => s._id === selectedId
    );

    return (
        <div>
            <h2>List Student</h2>
            {loading && <p>Loading students...</p>}
            {error && <p style={{ color: "red" }}>{error}</p>}
            <label>Select Student: </label>
            <select
                value={selectedId}
                onChange={e => setSelectedId(e.target.value)}
            >
                <option value="">-- Select Student --</option>

                {students.map(s => (
                    <option key={s._id} value={s._id}>
                        {s.name}
                    </option>
                ))}
            </select>
            <br /><br />
            <Link to="/CreateStudent">Create Student</Link>

            {student && (
                <>
                    <h3>Student Details</h3>

                    <table border="1" >
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Image</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{student.id}</td>
                                <td>{student.name}</td>
                                <td>{student.mobile}</td>
                                <td>{student.email}</td>
                                <td>{student.address}</td>
                                <td>
                                    <img
                                        src={`/${student.image}`}
                                        alt={student.name}
                                        width="80"
                                        height="80"
                                        style={{ objectFit: "cover" }}
                                    />
                                </td>
                                <td>
                                    <Link
                                        to={`/UpdateStudent/${student._id}`}>
                                        Update
                                    </Link>
                                    {" | "}
                                    <Link
                                        to={`/DeleteStudent/${student._id}`}>
                                        Delete
                                    </Link>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </>
            )}
        </div>
    );
}

export default ListStudent;