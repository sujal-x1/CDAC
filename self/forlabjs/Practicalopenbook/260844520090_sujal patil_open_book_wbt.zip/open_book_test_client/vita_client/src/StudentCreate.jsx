import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";

function StudentCreate() {
    const navigate = useNavigate();
    const [student, setStudent] = useState({
        name: "",
        mobile: "",
        email: "",
        address: "",
        image: ""
    });
    const [error, setError] = useState("");

    const handleChange = e => {
        setStudent({ ...student, [e.target.name]: e.target.value });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        setError("");

        try {
            const response = await fetch("http://localhost:8083/student", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(student)
            });

            const data = await response.json();
            if (!response.ok) throw new Error(data.message || "Create failed");

            alert("Student created successfully");
            navigate("/ListStudent");
        } catch (err) {
            setError(err.message);
        }
    };

    return (
        <div>
            <h2>Create Student</h2>
            {error && <p style={{ color: "red" }}>{error}</p>}

            <form onSubmit={handleSubmit}>
                <label>Name:</label>
                <input name="name" value={student.name} onChange={handleChange} required />
                <br /><br />

                <label>Mobile:</label>
                <input name="mobile" value={student.mobile} onChange={handleChange} required />
                <br /><br />

                <label>Email:</label>
                <input type="email" name="email" value={student.email} onChange={handleChange} required />
                <br /><br />

                <label>Address:</label>
                <input name="address" value={student.address} onChange={handleChange} required />
                <br /><br />

                <label>Image filename:</label>
                <input name="image" placeholder="Raj.png" value={student.image} onChange={handleChange} required />
                <br /><br />

                <button type="submit">Save Student</button>
                {" "}
                <Link to="/ListStudent">Cancel</Link>
            </form>
        </div>
    );
}

export default StudentCreate;